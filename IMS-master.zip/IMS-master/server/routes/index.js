module.exports.auth = require("./auth");

module.exports.internships = require("./internship");

module.exports.admin = require("./admin");

module.exports.notices = require("./notices");

module.exports.Faculty = require("./faculty");
