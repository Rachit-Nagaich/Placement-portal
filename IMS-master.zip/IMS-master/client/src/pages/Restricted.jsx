import React, { Component } from "react";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";

class Restricted extends Component {
  render() {
    return <h4>Loading...</h4>;
  }
}

export default Restricted;
